import calculator from "./calculator";

const sum = calculator.sum(1, 2);
console.log(sum);

const sub = calculator.sub(1, 2);
console.log(sub);

const mul = calculator.mul(1, 2);
console.log(mul);

const div = calculator.div(1, 2);
console.log(div);